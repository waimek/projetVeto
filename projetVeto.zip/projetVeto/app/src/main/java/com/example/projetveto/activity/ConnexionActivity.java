package com.example.projetveto.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projetveto.R;

public class ConnexionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connexion);
    }
}
