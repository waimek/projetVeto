package com.example.projetveto.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class InfosProprietaireActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infos_proprietaire);
    }
}
