package com.example.projetveto.activity.adapter;

public class RendezVousAdapter {
}
